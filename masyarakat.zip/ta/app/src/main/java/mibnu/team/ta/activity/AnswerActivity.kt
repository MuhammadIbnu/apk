package mibnu.team.ta.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import kotlinx.android.synthetic.main.activity_answer.*
import mibnu.team.ta.R
import mibnu.team.ta.models.Tracking
import mibnu.team.ta.utils.Utilities
import mibnu.team.ta.viewmodels.TrackViewModel

class AnswerActivity : AppCompatActivity() {
    private lateinit var trackViewModel: TrackViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_answer)
        trackViewModel = ViewModelProvider(this).get(TrackViewModel::class.java)
        trackViewModel.listenToDatas().observe(this, Observer { attachToUI(it) })
        Utilities.getToken(this)?.let { token -> trackViewModel.trackData(token) }
    }

    private fun attachToUI(track:Tracking){
        if(track.answerReport == null){
            area.visibility = View.GONE
        }else{
            area.visibility = View.VISIBLE
            isi.text = track.answerReport
            date.text = track.dateAnswerReport
        }
    }
}