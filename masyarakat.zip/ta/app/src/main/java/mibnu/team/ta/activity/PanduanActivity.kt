package mibnu.team.ta.activity

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import mibnu.team.ta.R

class PanduanActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_panduan)
    }
}