package mibnu.team.ta.activity

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import coil.api.load
import com.fxn.pix.Pix
import kotlinx.android.synthetic.main.activity_report.*
import mibnu.team.ta.R
import mibnu.team.ta.models.Report
import mibnu.team.ta.utils.Utilities
import mibnu.team.ta.viewmodels.ReportState
import mibnu.team.ta.viewmodels.ReportViewModel
import java.io.File

class ReportActivity : AppCompatActivity() {
    private lateinit var reportViewModel: ReportViewModel
    private var imgUrl = ""
    private val REQ_CODE_PIX = 101
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_report)

        reportViewModel = ViewModelProvider(this).get(ReportViewModel::class.java)
        reportViewModel.listenUIState().observe(this, Observer { handleUI(it) })
        imageReport.setOnClickListener { Pix.start(this, REQ_CODE_PIX) }
        reportYu()
    }

    private fun handleUI(it: ReportState) {
    when(it){
        is ReportState.ShowToast -> toast(it.message)
        is ReportState.Success -> finish()
    }

    }

    private fun reportYu(){
        submit.setOnClickListener {
            val report = isi.text.toString().trim()
            if (validate(report)){
                reportViewModel.reportData("${Utilities.getToken(this@ReportActivity)!!}",report, imgUrl)
            }

        }
    }
    fun validate(lapor:String): Boolean{
        if (lapor.isEmpty()){
            isi.error="laporan harap diisi"
            return false
        }
        return true
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQ_CODE_PIX && resultCode == Activity.RESULT_OK && data != null){
            val selectedImageUri = data.getStringArrayListExtra(Pix.IMAGE_RESULTS)
            selectedImageUri?.let{
                imgUrl = it[0]
                imageReport.load(File(it[0]) )
            }
        }
    }



    private fun toast(message: String) = Toast.makeText(this@ReportActivity, message, Toast.LENGTH_SHORT).show()
}