package mibnu.team.ta.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import mibnu.team.ta.models.Finishes
import mibnu.team.ta.utils.SingleLiveEvent
import mibnu.team.ta.webservices.ApiClient
import mibnu.team.ta.webservices.WrappedResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FinishesViewModel :ViewModel(){
    private  val api = ApiClient.instanceBackend()
    private  val state : SingleLiveEvent<FinishesState> = SingleLiveEvent()
    private  var finishesdatas = MutableLiveData<List<Finishes>>()

    private fun setLoading(){state.value = FinishesState.IsLoading(true)}
    private fun hideLoading(){state.value = FinishesState.IsLoading(false)}
    private fun showToast(mesage : String){state.value = FinishesState.ShowToast(mesage)}

    fun finishesS(token:String, status_data:Boolean){
        println(token)
        state.value=FinishesState.IsLoading(true)
        api.finishesData(token, status_data).enqueue(object : Callback<WrappedResponse<Finishes>>{
            override fun onResponse(
                call: Call<WrappedResponse<Finishes>>,
                response: Response<WrappedResponse<Finishes>>
            ) {
                if (response.isSuccessful){
                    val body = response.body() as WrappedResponse
                    if (body.status){
                        state.value = FinishesState.ShowToast("Berhasil")
                        state.value = FinishesState.Success
                    }else{
                        state.value = FinishesState.ShowToast("gagal cek")
                    }
                }else{
                    state.value = FinishesState.ShowToast("gagal")
                }
                state.value = FinishesState.IsLoading(false)
            }

            override fun onFailure(call: Call<WrappedResponse<Finishes>>, t: Throwable) {
                println("onFailure : "+t.message)
                println(t.printStackTrace())
                state.value = FinishesState.ShowToast("onFailure : "+t.message)
            }

        })
    }


    fun listenToUIState() = state
    fun listenToDatas() = finishesdatas
}

sealed class FinishesState{
    data class IsLoading(var state : Boolean) : FinishesState()
    data class ShowToast(var message : String) : FinishesState()
    object Reset : FinishesState()
    object Success: FinishesState()
}