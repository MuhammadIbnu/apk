package mibnu.team.petugas.models

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Koment(
    @SerializedName("id") var id : Int? = null,
    @SerializedName("waris") var waris : Waris? = null,
    @SerializedName("nilai") var nilai : Int? = null,
    @SerializedName("komentar") var komentar : String? = null,
    @SerializedName("created_at") var created_at : String? = null
) : Parcelable