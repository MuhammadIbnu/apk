package mibnu.team.petugas.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_data_valid.*
import mibnu.team.petugas.R
import mibnu.team.petugas.adapter.DataFinalAdapter
import mibnu.team.petugas.adapter.DataReportAdapter
import mibnu.team.petugas.models.Data
import mibnu.team.petugas.utils.Utilities
import mibnu.team.petugas.viewmodels.DataAnswerReportViewModel
import mibnu.team.petugas.viewmodels.ReportState

class DataReportActivity : AppCompatActivity() {
    private lateinit var dataAnswerReportViewModel : DataAnswerReportViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_report)
        setupUi()
        dataAnswerReportViewModel = ViewModelProvider(this).get(DataAnswerReportViewModel::class.java)
        dataAnswerReportViewModel.listenToUiState().observer(this, Observer { handleUIState(it) })
        dataAnswerReportViewModel.listenToDataReport().observe(this, Observer { handleData(it) })
    }

    private fun setupUi() {
        rv_data.apply {
            layoutManager = LinearLayoutManager(this@DataReportActivity)
            adapter = DataReportAdapter(mutableListOf(),this@DataReportActivity)
        }
    }

    private fun handleData(it : List<Data>){
        rv_data.adapter?.let { adapter ->
            adapter as DataReportAdapter
            adapter.updateList(it)
        }
    }

    private fun handleUIState(it:ReportState){
        when(it){
            is ReportState.ShowToast -> toast(it.message)
            is ReportState.IsLoading ->{
                if (it.state){
                    loading.visibility = View.VISIBLE
                }else{
                    loading.visibility = View.GONE
                }
            }
        }
    }

    private fun toast(m : String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    override fun onResume() {
        super.onResume()
        Utilities.getToken(this)?.let { t -> dataAnswerReportViewModel.fetchReport("Bearer $t") }
    }
}