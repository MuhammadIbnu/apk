package mibnu.team.petugas.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_data_valid.view.*
import mibnu.team.petugas.R
import mibnu.team.petugas.models.Data
import mibnu.team.petugas.view.DetailDataConfirmedIIActivity
import mibnu.team.petugas.view.DetailDataReportActivity

class DataReportAdapter (private  var dataReport:MutableList<Data>, private  var context: Context):
    RecyclerView.Adapter<DataReportAdapter.ViewHolder>(){
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataReportAdapter.ViewHolder =
        DataReportAdapter.ViewHolder(
            LayoutInflater.from(parent.context).inflate(R.layout.item_data_valid, parent, false)
        )

    override fun onBindViewHolder(holder: DataReportAdapter.ViewHolder, position: Int) = holder.bind(dataReport[position], context)

    override fun getItemCount()=dataReport.size

    fun updateList(ls:List<Data>){
        dataReport.clear()
        dataReport.addAll(ls)
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
        fun bind(d : Data, context: Context){
            with(itemView){
                tv_nik.text = d.waris?.nik.toString()
                tv_name.text = d.waris!!.nama
                if (d.confirmedII==true){
                    val dataReceived : TextView = findViewById(R.id.icon)
                    icon1.visibility = View.GONE
                    val hasil ="Diterima"
                    dataReceived.text=hasil
                }else if(d.confirmedII==null){
                    val dataReceived : TextView = findViewById(R.id.icon2)
                    icon1.visibility=View.GONE
                    icon.visibility=View.GONE
                    val hasil ="belum diperiksa"
                    dataReceived.text=hasil
                }else{
                    icon2.visibility=View.GONE
                    icon.visibility=View.GONE
                    val dataReceived : TextView = findViewById(R.id.icon1)
                    val hasil ="DiTolak"
                    dataReceived.text=hasil
                }
                setOnClickListener {
                    context.startActivity(Intent(context, DetailDataReportActivity::class.java).apply {
                        putExtra("DATA", d)
                    })
                }
            }
        }

    }

}
