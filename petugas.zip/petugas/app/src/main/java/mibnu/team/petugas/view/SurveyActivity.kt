package mibnu.team.petugas.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.anychart.APIlib
import com.anychart.AnyChart
import com.anychart.chart.common.dataentry.DataEntry
import com.anychart.chart.common.dataentry.ValueDataEntry
import com.anychart.enums.Align
import com.anychart.enums.LegendLayout
import kotlinx.android.synthetic.main.activity_survey.*
import kotlinx.android.synthetic.main.chart_pie.*
import mibnu.team.petugas.R
import mibnu.team.petugas.adapter.DataListAdapter
import mibnu.team.petugas.models.Koment
import mibnu.team.petugas.models.Survey
import mibnu.team.petugas.utils.Utilities
import mibnu.team.petugas.viewmodels.SurveyViewModel

class SurveyActivity : AppCompatActivity() {
    private lateinit var surveyViewModel: SurveyViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_survey)
        surveyViewModel = ViewModelProvider(this).get(SurveyViewModel::class.java)
        surveyViewModel.fectSurvey()
        surveyViewModel.fectComment()
        surveyViewModel.listenToInfo().observe(this, Observer { attachSurveyInfo(it) })
        surveyViewModel.listenTDatas().observe(this, Observer { handleData(it) })

    }

    private fun attachSurveyInfo(it:Survey){
        kurang.setText(it.bad.toString())
        cukup.setText(it.enough.toString())
        baik.setText(it.good.toString())
        var bad= it.bad
        var enough=it.enough
        var good=it.good
        val hasil = "${bad+enough+good}"
        println(bad+enough+good)
        jmlResponder.setText(hasil)
//        jmlResponder.setText(bad+enough+good)
        pie_chart.setProgressBar(progress_chart)
        APIlib.getInstance().setActiveAnyChartView(pie_chart)
        val pie = AnyChart.pie()
        val data:MutableList<DataEntry> = mutableListOf()
        data.add(ValueDataEntry("Baik",it.good))
        data.add(ValueDataEntry("Cukup",it.enough))
        data.add(ValueDataEntry("Buruk",it.bad))
        pie.data(data)
        pie.title("Hasil Survey Kepuasan Masyarakat")
        pie.labels().position("outsider")
        pie.legend().title().enabled(true)
        pie.legend().position("center-buttom").itemsLayout(LegendLayout.HORIZONTAL).align(Align.CENTER)
        pie_chart.setChart(pie)

        rv_data.apply {
            layoutManager = LinearLayoutManager(this@SurveyActivity)
            adapter = DataListAdapter(mutableListOf(), this@SurveyActivity)
        }
    }

    private fun handleData(it : List<Koment>){
        rv_data.adapter?.let {
            adapter ->
            adapter as DataListAdapter
            adapter.updateList(it)
        }
    }

}
