package mibnu.team.petugas.adapter

import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.recyclerview.widget.RecyclerView
import kotlinx.android.synthetic.main.item_data_rec.view.*
import kotlinx.android.synthetic.main.item_data_valid.view.*
import kotlinx.android.synthetic.main.item_data_rec.view.tv_name
import kotlinx.android.synthetic.main.item_data_rec.view.tv_nik
import mibnu.team.petugas.R
import mibnu.team.petugas.models.Data
import mibnu.team.petugas.models.Koment
import mibnu.team.petugas.view.DetailDataConfirmedIIActivity

class DataListAdapter (private  var dataValid:MutableList<Koment>, private  var context: Context):RecyclerView.Adapter<DataListAdapter.ViewHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder = ViewHolder(
        LayoutInflater.from(parent.context).inflate(R.layout.item_data_rec, parent,false))

    override fun getItemCount()=dataValid.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int)= holder.bind(dataValid[position], context)

    fun updateList(ls : List<Koment>){
        dataValid.clear()
        dataValid.addAll(ls)
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View):RecyclerView.ViewHolder(itemView) {
        fun bind(d : Koment, context: Context){
            with(itemView){
                tv_nik.text = d.waris?.nik.toString()
                tv_name.text = d.waris!!.nama
                tv_reaksi.text= d.komentar.toString()
                if (d.nilai==1){
                    img_kurang.visibility=View.VISIBLE
                }else if (d.nilai==2){
                    img_cukup.visibility=View.VISIBLE
                }else{
                    img_baik.visibility=View.VISIBLE
                }
            }
        }

    }

}