package mibnu.team.petugas.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import mibnu.team.petugas.models.Data
import mibnu.team.petugas.utils.SingleLiveEvent
import mibnu.team.petugas.webservice.ApiClient
import mibnu.team.petugas.webservice.WreppedListResponse
import mibnu.team.petugas.webservice.WreppedRespond
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DataAnswerReportViewModel : ViewModel(){
    private  val api = ApiClient.instance()
    private var state:SingleLiveEvent<ReportState> = SingleLiveEvent()
    private var reports = MutableLiveData<List<Data>>()

    private fun setLoading(){state.value = ReportState.IsLoading(true)}
    private fun hideLoading(){state.value = ReportState.IsLoading(false)}
    private fun showToast(message:String){ state.value = ReportState.ShowToast(message)}

    fun fetchReport(token: String){
        setLoading()
        api.dataReport(token).enqueue(object : Callback<WreppedListResponse<Data>>{
            override fun onResponse(
                call: Call<WreppedListResponse<Data>>,
                response: Response<WreppedListResponse<Data>>
            ) {
                if (response.isSuccessful){
                    val body = response.body()
                    println(body.toString())
                    reports.postValue(body?.data)
                }else{
                    showToast("Kesalahan saat mengambil data")
                }
                hideLoading()
            }

            override fun onFailure(call: Call<WreppedListResponse<Data>>, t: Throwable) {
                println(t.printStackTrace())
                println(t.message)
                hideLoading()
                showToast(t.message.toString())
            }

        })
    }

    fun answer(token:String,id:Int,answer_report:String){
        state.value=ReportState.IsLoading(true)
        api.answerReport(token,id.toString(),answer_report).enqueue(object : Callback<WreppedRespond<Data>>{
            override fun onResponse(
                call: Call<WreppedRespond<Data>>,
                response: Response<WreppedRespond<Data>>
            ) {
                if (response.isSuccessful){
                    val body = response.body()
                    if (body?.status!!){
                        state.value = ReportState.ShowToast("Data Berhasil dikonfrimasi")
                        state.value = ReportState.Success

                    }else{
                        state.value = ReportState.ShowToast("gagal")
                    }
                }else{
                    state.value = ReportState.ShowToast("gagal")
                    println("gagal")
                }
                state.value = ReportState.IsLoading(false)
            }

            override fun onFailure(call: Call<WreppedRespond<Data>>, t: Throwable) {
                println("onFailure :"+t.message)
                println(t.printStackTrace())
                state.value = ReportState.ShowToast("onFailure : "+t.message)
            }

        })
    }

    fun listenToUiState()=state
    fun listenToDataReport()= reports
}

sealed class ReportState {
    data class IsLoading(var state : Boolean) : ReportState()
    data class ShowToast(var message : String) : ReportState()
    object Reset : ReportState()
    object Success: ReportState()
}