package mibnu.team.petugas.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.activity_detail_data_baru.*
import kotlinx.android.synthetic.main.activity_detail_data_baru.img_Akta_kematian
import kotlinx.android.synthetic.main.activity_detail_data_baru.img_Ktp_Meninggal
import kotlinx.android.synthetic.main.activity_detail_data_baru.img_buku_tabungan
import kotlinx.android.synthetic.main.activity_detail_data_baru.img_integritas_waris
import kotlinx.android.synthetic.main.activity_detail_data_baru.img_jamkesmas
import kotlinx.android.synthetic.main.activity_detail_data_baru.img_kk_meninggal
import kotlinx.android.synthetic.main.activity_detail_data_baru.img_kk_waris
import kotlinx.android.synthetic.main.activity_detail_data_baru.img_ktp_waris
import kotlinx.android.synthetic.main.activity_detail_data_baru.img_pernyataan_waris
import kotlinx.android.synthetic.main.activity_detail_data_baru.kk
import kotlinx.android.synthetic.main.activity_detail_data_baru.nama
import kotlinx.android.synthetic.main.activity_detail_data_baru.nik
import kotlinx.android.synthetic.main.activity_detail_data_report.*
import mibnu.team.petugas.R
import mibnu.team.petugas.models.Data
import mibnu.team.petugas.utils.Utilities
import mibnu.team.petugas.viewmodels.DataAnswerReportViewModel
import mibnu.team.petugas.viewmodels.DataState
import mibnu.team.petugas.viewmodels.ReportState

class DetailDataReportActivity : AppCompatActivity() {
    private lateinit var dataAnswerReportViewModel: DataAnswerReportViewModel
    private lateinit var answer:String
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_data_report)
        dataAnswerReportViewModel = ViewModelProvider(this).get(DataAnswerReportViewModel::class.java)
        dataAnswerReportViewModel.listenToUiState().observer(this, Observer { handleUi(it) })
    fill()
        kirim()
    }

    private fun kirim() {
        btn_answer.setOnClickListener {
            var id = getPassedData()?.kodeBerkas!!
            var answer = isitext.text.toString().trim()
            if (validate(answer)){
                dataAnswerReportViewModel.answer("Bearer ${Utilities.getToken(this@DetailDataReportActivity)!!}",id,answer)
            }


        }
    }
    fun validate(answer : String) :Boolean{
        if (answer.isEmpty()){
            isitext.error="jangan kosong"
            return false
        }
        return true

    }

    private fun handleUi(it: ReportState) {
        when(it){
            is ReportState.ShowToast -> Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show()
            is ReportState.Success -> finish()
        }

    }
    private fun getPassedData() = intent.getParcelableExtra<Data>("DATA")
    private fun fill(){
        getPassedData()?.let {
            nama.text = it.waris!!.nama
            kk.text = it.waris!!.kk
            nik.text = it.waris!!.nik
            if (it.confirmedI==true){
                status.text = "Sudah DiPeriksa"
            }else if (it.confirmedI==null){
                status.text = "Belum Diperiksa"
            }else{
                status.text = "Sudah diperiksa"
            }
            laporan.text=it.report
            dateLaporan.text=it.dateReport

            Glide.with(this)
                .load( it.ktpMeninggalUrl)
                .apply(RequestOptions())
                .into(img_Ktp_Meninggal)
            Glide.with(this)
                .load( it.kkMeninggalUrl)
                .apply(RequestOptions())
                .into(img_kk_meninggal)
            Glide.with(this)
                .load( it.jamkesmasMeninggalUrl)
                .apply(RequestOptions())
                .into(img_jamkesmas)
            Glide.with(this)
                .load( it.ktpWarisUrl)
                .apply(RequestOptions())
                .into(img_ktp_waris)
            Glide.with(this)
                .load(it.kkWarisUrl)
                .apply(RequestOptions())
                .into(img_kk_waris)
            Glide.with(this)
                .load( it.aktaKematianUrl)
                .apply(RequestOptions())
                .into(img_Akta_kematian)
            Glide.with(this)
                .load( it.paktaWarisUrl)
                .apply(RequestOptions())
                .into(img_integritas_waris)
            Glide.with(this)
                .load( it.pernyataanWarisUrl)
                .apply(RequestOptions())
                .into(img_pernyataan_waris)
            Glide.with(this)
                .load(it.bukuTabungan)
                .apply(RequestOptions())
                .into(img_buku_tabungan)
            Glide.with(this)
                .load(it.imageReport)
                .apply(RequestOptions())
                .into(imgReport)

        }
    }

}