<?php $__env->startSection('title'); ?>
    Data Pengajuan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a href="<?php echo e(route('aktivitas.index')); ?>" class="btn btn-success">Back</a>
                </div>
                <div class="box-body">
                   <table class="table table-bordered">
                       <tr>
                           <td>nik ahli waris</td>
                           <td>:</td>
                           <td><?php echo e($aktivitas->waris->nik); ?></td>
                       </tr>
                        <tr>
                            <td>kk ahlis waris</td>
                            <td>:</td>
                            <td><?php echo e($aktivitas->waris->kk); ?></td>
                        </tr>
                        <tr>
                            <td>nama ahli waris</td>
                            <td>:</td>
                            <td><?php echo e($aktivitas->waris->nama); ?></td>
                        </tr>
                        <tr>
                            <td>Jenis Kelamin</td>
                            <td>:</td>
                            <td><?php echo e($aktivitas->waris->jk); ?></td>
                        </tr>
                        <tr>
                            <td>Berkas</td>
                            <td>:</td>
                            <td>
                                <div class="row">
                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($aktivitas->ktp_meninggal)); ?>" target="_blank">
                                                <img src="<?php echo e(asset($aktivitas->ktp_meninggal)); ?>" alt="Lights" style="width:100%">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($aktivitas->kk_meninggal)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($aktivitas->kk_meninggal)); ?>" alt="Nature" style="width:100%">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($aktivitas->jamkesmas)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($aktivitas->jamkesmas)); ?>" alt="Fjords" style="width:100%">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                            <a href="<?php echo e(asset($aktivitas->ktp_waris)); ?>" target="_blank">
                                                <img src="<?php echo e(asset($aktivitas->ktp_waris)); ?>" alt="Fjords" style="width:100%">
                                            </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                            <a href="<?php echo e(asset($aktivitas->kk_waris)); ?>" target="_blank">
                                                <img src="<?php echo e(asset($aktivitas->kk_waris)); ?>" alt="Lights" style="width:100%">
                                            </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($aktivitas->akta_kematian)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($aktivitas->akta_kematian)); ?>" alt="Nature" style="width:100%">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($aktivitas->pakta_waris)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($aktivitas->pakta_waris)); ?>" alt="Nature" style="width:100%">
                                                </a>
                                            </div>
                                        </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>pengecekan Data Masuk</td>
                            <td>:</td>
                            <td><?php if($aktivitas->confirmed_I === 1): ?><button type="button" class="btn btn-primary"> Sukses </button> 
                                <?php elseif($aktivitas->confirmed_I === null): ?><button type="button" class="btn btn-warning"> sedang divalidasi </button>
                                <?php else: ?> <button type="button" class="btn btn-danger"> gagal </button>  
                                <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td>pengecekan dinas sosial</td>
                            <td>:</td>
                            <td><?php if($aktivitas->confirmed_II == 1): ?><button type="button" class="btn btn-primary"> Sukses </button>
                                <?php elseif($aktivitas->confirmed_II === null): ?><button type="button" class="btn btn-warning"> sedang divalidasi </button> 
                                <?php else: ?> <button type="button" class="btn btn-danger"> Belum </button>  
                                <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td>Pengesahan</td>
                            <td>:</td>
                            <td><?php if($aktivitas->confirmed_III == 1): ?><button type="button" class="btn btn-primary"> Sukses </button>
                                <?php elseif($aktivitas->confirmed_III === null): ?><button type="button" class="btn btn-warning"> sedang divalidasi </button> 
                                <?php else: ?> <button type="button" class="btn btn-danger"> belum </button>  
                            <?php endif; ?></td>
                        </tr>
                   </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ta\resources\views/aktivitas/show.blade.php ENDPATH**/ ?>