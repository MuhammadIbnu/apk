<html>
<head>
	<title>Laporan</title>
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h5>Laporan Daftar Pengesahan Bantuan Uang Duka Kota Tegal</h4>
	</center>
 
	<table class='table table-bordered'>
		<thead>
			<tr>
				<th>No</th>
				<th>nomor nik</th>
				<th>nomor kk</th>
				<th>nama</th>
				<th>Tanggal pengesahan data</th>
				<th>Pengesahan data</th>
                <th>Petugas</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $report_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($loop->iteration); ?></td>
				<td><?php echo e($row->waris->nik); ?></td>
				<td><?php echo e($row->waris->kk); ?></td>
				<td><?php echo e($row->waris->nama); ?></td>
				<td><?php echo e($row->updated_at->format('d/m/Y')); ?></td>
				<td><?php if($row->confirmed_III == 1): ?><i>sukses</if>   
                    <?php endif; ?></td>
                <td><?php echo e($row->petugas->nama); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</body>
</html><?php /**PATH C:\xampp\htdocs\ta\resources\views/report_data/data_pdf.blade.php ENDPATH**/ ?>