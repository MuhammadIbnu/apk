<?php $__env->startSection('title'); ?>
    Data Pengajuan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <a href="<?php echo e(route('report.index')); ?>" class="btn btn-success">Back</a>
                </div>
                <div class="box-body">
                   <table class="table table-bordered">
                       <tr>
                           <td>nik ahli waris</td>
                           <td>:</td>
                           <td><?php echo e($report->waris->nik); ?></td>
                       </tr>
                        <tr>
                            <td>kk ahlis waris</td>
                            <td>:</td>
                            <td><?php echo e($report->waris->kk); ?></td>
                        </tr>
                        <tr>
                            <td>nama ahli waris</td>
                            <td>:</td>
                            <td><?php echo e($report->waris->nama); ?></td>
                        </tr>
                        <tr>
                            <td>Jenis Kelamin</td>
                            <td>:</td>
                            <td><?php echo e($report->waris->jk); ?></td>
                        </tr>
                        <tr>
                            <td>Berkas</td>
                            <td>:</td>
                            <td>
                                <div class="row">
                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($report->ktp_meninggal)); ?>" target="_blank">
                                                <img src="<?php echo e(asset($report->ktp_meninggal)); ?>" alt="Lights" style="width:100%">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($report->kk_meninggal)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($report->kk_meninggal)); ?>" alt="Nature" style="width:100%">
                                                </a>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($report->jamkesmas)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($report->jamkesmas)); ?>" alt="Fjords" style="width:100%">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                            <a href="<?php echo e(asset($report->ktp_waris)); ?>" target="_blank">
                                                <img src="<?php echo e(asset($report->ktp_waris)); ?>" alt="Fjords" style="width:100%">
                                            </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                            <a href="<?php echo e(asset($report->kk_waris)); ?>" target="_blank">
                                                <img src="<?php echo e(asset($report->kk_waris)); ?>" alt="Lights" style="width:100%">
                                            </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($report->akta_kematian)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($report->akta_kematian)); ?>" alt="Nature" style="width:100%">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($report->pakta_waris)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($report->pakta_waris)); ?>" alt="Nature" style="width:100%">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($report->pernyataan_ahli_waris)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($report->pernyataan_ahli_waris)); ?>" alt="Nature" style="width:100%">
                                                </a>
                                            </div>
                                        </div>

                                        <div class="col-md-4">
                                            <div class="thumbnail">
                                                <a href="<?php echo e(asset($report->buku_tabungan)); ?>" target="_blank">
                                                    <img src="<?php echo e(asset($report->buku_tabungan)); ?>" alt="Nature" style="width:100%">
                                                </a>
                                            </div>
                                        </div>
                                </div>
                            </td>
                        </tr>
                        <tr>
                            <td>pengecekan Data Masuk</td>
                            <td>:</td>
                            <td><?php if($report->confirmed_I === true): ?><button type="button" class="btn btn-primary"> Sukses </button> 
                                <?php elseif($report->confirmed_I === null): ?><button type="button" class="btn btn-warning"> sedang divalidasi </button>
                                <?php else: ?> <button type="button" class="btn btn-danger"> gagal </button>  
                                <?php endif; ?></td>
                        </tr>
                        <tr>
                            <td>Badan Keuangan Daerah</td>
                            <td>:</td>
                            <td><?php if($report->confirmed_II == true): ?><button type="button" class="btn btn-primary"> Sukses </button>
                                <?php elseif($report->confirmed_II === null): ?><button type="button" class="btn btn-warning"> sedang divalidasi </button> 
                                <?php else: ?> <button type="button" class="btn btn-danger"> gagal </button>  
                                <?php endif; ?></td>
                        </tr>
                        
                   </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tafix\ta\resources\views/report/show.blade.php ENDPATH**/ ?>