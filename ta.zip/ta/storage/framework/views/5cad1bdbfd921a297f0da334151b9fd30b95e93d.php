<html>
<head>
	<title>Laporan</title>
</head>
<body>
	<style type="text/css" media="all">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h5>Laporan Daftar Pengesahan Bantuan Uang Duka Kota Tegal</h4>
	</center>
 
	<table class='table table-bordered'>
		<thead>
			<tr>
				<th>No</th>
				<th>nomor nik</th>
				<th>nomor kk</th>
				<th>nama</th>
				<th>Tanggal pengesahan data</th>
			</tr>
		</thead>
		<tbody>
			<?php $__currentLoopData = $filter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($loop->iteration); ?></td>
				<td><?php echo e($row->waris->nik); ?></td>
				<td><?php echo e($row->waris->kk); ?></td>
				<td><?php echo e($row->waris->nama); ?></td>
				<td><?php echo e($row->updated_at->format('d/m/Y')); ?></td>
			</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</tbody>
	</table>
</body>
</html><?php /**PATH C:\xampp\htdocs\ta\resources\views/report_bakuda/data_pdf.blade.php ENDPATH**/ ?>