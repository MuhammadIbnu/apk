<?php $__env->startSection('title'); ?>
   Report Data 
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <?php if( Request::get('start_date') != "" && Request::get('end_date') != ""): ?>
                    <a class="btn btn-success"  href="<?php echo e(route('report_data')); ?>">Back</a>
                    <?php endif; ?>
                    <br/>
                    <br/>
                    <form method="get" action="<?php echo e(route('report_data')); ?>">
                        <div class="form-group">
                        <label for="nama_produk" class="col-sm-2 control-label">Search By Date</label>
                        <div class="col-sm-4">
                        <input type="text" readonly name="start_date" value="<?php echo e($start_date); ?>" placeholder="Start Date" class="form-control datepicker"/>
                        </div>
                        <div class="col-sm-4">
                        <input type="text" readonly name="end_date" value="<?php echo e($end_date); ?>" placeholder="Finish Date" class="form-control datepicker"/>
                        </div>
                        <div class="col-sm-2">
                        <button type="submit" class="btn btn-info"><span class="glyphicon glyphicon-search"></span></button>
                        </div>
                        </div>
                    </form>

                    <form method="get" action="<?php echo e(route('cetak_pdf')); ?>" target="_blank">
                        <input type="hidden" name="start_date" value="<?php echo e($start_date); ?>"/>
                            <input type="hidden" name="end_date" value="<?php echo e($end_date); ?>"/>
                            <button type="submit" class="btn btn-success">PDF</button>
                    </form>
                </div>
                <div class="box-body">
                    <?php if( Request::get('start_date') != "" && Request::get('end_date') != ""): ?>
                    <div class="alert alert-success alert-block">
                    Hasil Pencarian Transaksi Masuk Dari Tanggal :  <?php echo e($start_date); ?> s/d  <?php echo e($end_date); ?> 
                    </div>            
                    <?php endif; ?>
                    <?php echo $__env->make('alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Nik</th>
                                <th>KK</th>
                                <th>Nama</th>
                                <th>Tanggal Pengesahan</th>
                                <th>Status berkas</th>
                                <th width="30%">Petugas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $report_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration + ($report_data->perPage() *($report_data->currentPage()-1))); ?> </td>
                                    <td><?php echo e($row->waris->nik); ?></td>
                                    <td><?php echo e($row->waris->kk); ?></td>
                                    <td><?php echo e($row->waris->nama); ?></td>
                                    <td><?php echo e($row->updated_at->format('d/m/Y')); ?></td>
                                    <td><?php if($row->confirmed_II == 1): ?><button type="button" class="btn btn-primary">sukses</button>   
                                    <?php endif; ?></td>
                                    <td><?php echo e($row->petugas->nama); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($report_data->appends(Request::All())->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tafix\ta\resources\views/report_data/index.blade.php ENDPATH**/ ?>