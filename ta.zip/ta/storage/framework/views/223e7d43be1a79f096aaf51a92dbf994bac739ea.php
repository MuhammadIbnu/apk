<?php if(session('status')): ?>
<div class="alert alert-success alert-block">
    <button type="button" class="close" data-dismiss="alert">x</button>
    <strong><?php echo e(session('status')); ?></strong>
</div>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\tafix\ta\resources\views/alert/success.blade.php ENDPATH**/ ?>