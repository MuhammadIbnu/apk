<?php $__env->startSection('title'); ?>
    Edit data Petugas Disdukcapil
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border"> 
                      <?php echo $__env->make('alert.error', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>
                <div class="box-body">
                    <form class="form-horizontal" method="post" action="<?php echo e(route('petugas.update',[$petugas->id])); ?>">
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('PUT')); ?>

                        <div class="box-body">
                            <div class="form-group">
                                <label for="username" class="col-sm-2 control-label">Username</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="username" disabled value="<?php echo e($petugas->username); ?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="nama_pegawai" class="col-sm-2 control-label">Nama Petugas</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" maxlength="50" placeholder="Maksimal karakter adalah 50" id="nama" name="nama" value="<?php echo e($petugas->nama); ?>">
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button type="submit" name="tombol" class="btn btn-info pull-right">Update</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tafix\ta\resources\views/petugas/edit.blade.php ENDPATH**/ ?>