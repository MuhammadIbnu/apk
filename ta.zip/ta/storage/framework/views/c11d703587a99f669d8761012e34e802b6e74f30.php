<?php $__env->startSection('title'); ?>
    Data Petugas Dinas kesehatan
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <?php if(Request::get('keyword')): ?>
                        <a href="<?php echo e(route('dinkes.index')); ?>" class="btn btn-success">Back</a>
                    <?php else: ?>
                    <a href="<?php echo e(route('dinkes.create')); ?>" class="btn btn-success"><span class="glyphicon glyphicon-plus"></span>create</a>
                    <?php endif; ?>
                    <form action="<?php echo e(route('dinkes.index')); ?>" method="get">
                        <div class="fore-group">
                            <label for="keyword" class="col-sm-2 control-label">Search By name</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="keyword" name="keyword" value="<?php echo e(Request::get('keyword')); ?>">
                            </div>
                            <div class="col-sm-6">
                                <button type="submit" class="btn btn-info"><span class="glyphicon glyphicon-search"></span></button>
                            </div>
                        </div>
                    </form>
                   
                </div>
                <div class="box-body">
                    <?php if(Request::get('keyword')): ?>
                        <div class="alert alert-success alert-black">hasil pencarian dangan keyword: <b><?php echo e(Request::get('keyword')); ?></b></div>
                    <?php endif; ?>
                        <?php echo $__env->make('alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>username</th>
                                <th>nama</th>
                                <th width="30%">action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dinkes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration + ($dinkes->perPage() *($dinkes->currentPage()-1))); ?> </td>
                                    <td><?php echo e($row->username); ?></td>
                                    <td><?php echo e($row->nama); ?></td>
                                    <td>
                                        <form method="post" action="<?php echo e(route('dinkes.destroy',[$row->id])); ?>" onsubmit="return confirm('apakah anda yakin akan menghapus data ini?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo e(method_field('DELETE')); ?>

                                            <a href="<?php echo e(route('dinkes.edit',[$row->id])); ?>" class="btn btn-warning">Edit</a>
                                            <a href="<?php echo e(route('dinkes.reset',[$row->id])); ?>" onclick="return confirm('apakah anda yakin akan RESET data ini?')" class="btn btn-warning" >reset</a>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($dinkes->appends(Request::All())->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\ta\resources\views/dinkes/index.blade.php ENDPATH**/ ?>