<?php $__env->startSection('title'); ?>
    Data AKtivitas Petugas
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <?php if(Request::get('keyword')): ?>
                        <a href="<?php echo e(route('aktivitas.index')); ?>" class="btn btn-success">Back</a>
                    <?php endif; ?>
                    <form action="<?php echo e(route('aktivitas.index')); ?>" method="get">
                        <div class="fore-group">
                            <label for="keyword" class="col-sm-2 control-label">Search By name</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="keyword" name="keyword" value="<?php echo e(Request::get('keyword')); ?>">
                            </div>
                            <div class="col-sm-6">
                                <button type="submit" class="btn btn-info"><span class="glyphicon glyphicon-search"></span></button>
                            </div>
                        </div>
                    </form>
                   
                </div>
                <div class="box-body">
                    <?php if(Request::get('keyword')): ?>
                        <div class="alert alert-success alert-black">hasil pencarian dangan keyword: <b><?php echo e(Request::get('keyword')); ?></b></div>
                    <?php endif; ?>
                        <?php echo $__env->make('alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Nama pengaju</th>
                                <th>Tanggal pengajuan</th>
                                <th>Status berkas</th>
                                <th>Petugas</th>
                                <th width="30%">action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $aktivitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration + ($aktivitas->perPage() *($aktivitas->currentPage()-1))); ?> </td>
                                    <td><?php echo e($row->waris->nama); ?></td>
                                    <td><?php echo e($row->created_at->format('d/m/Y')); ?></td>
                                    <td><?php if($row->confirmed_II === true): ?>
                                        <button type="button" class="btn btn-success">Diterima</button> 
                                        <?php elseif($row->confirmed_II === null): ?>
                                        <button type="button" class="btn btn-warning">Sedang dievaluasi</button>  
                                        <?php else: ?>
                                        <button type="button" class="btn btn-danger">ditolak</button>
                                    <?php endif; ?></td>
                                    <td><?php echo e($row->petugas->nama); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('aktivitas.show',[$row->kd_berkas])); ?>" class="btn btn-info">Detail</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($aktivitas->appends(Request::All())->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tafix\ta\resources\views/aktivitas/index.blade.php ENDPATH**/ ?>