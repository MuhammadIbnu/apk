<?php $__env->startSection('title'); ?>
    Data Laporan Masyarakat
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <?php if(Request::get('keyword')): ?>
                        <a href="<?php echo e(route('report.index')); ?>" class="btn btn-success">Back</a>
                    <?php endif; ?>
                    <form action="<?php echo e(route('report.index')); ?>" method="get">
                        <div class="fore-group">
                            <label for="keyword" class="col-sm-2 control-label">Search By name</label>
                            <div class="col-sm-4">
                                <input type="text" class="form-control" id="keyword" name="keyword" value="<?php echo e(Request::get('keyword')); ?>">
                            </div>
                            <div class="col-sm-6">
                                <button type="submit" class="btn btn-info"><span class="glyphicon glyphicon-search"></span></button>
                            </div>
                        </div>
                    </form>
                   
                </div>
                <div class="box-body">
                    <?php if(Request::get('keyword')): ?>
                        <div class="alert alert-success alert-black">hasil pencarian dangan keyword: <b><?php echo e(Request::get('keyword')); ?></b></div>
                    <?php endif; ?>
                        <?php echo $__env->make('alert.success', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Nama pengaju</th>
                                <th>Pegawai Disdukcapil</th>
                                <th>Pegawai Bakeuda</th>
                                <th>Laporan</th>
                                <th>Tanggal pengajuan</th>
                                <th>Tanggal Lapor</th>
                                <th width="30%">action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration + ($report->perPage() *($report->currentPage()-1))); ?> </td>
                                    <td><?php echo e($row->waris->nama); ?></td>
                                    <td><?php if($row->petugas == null): ?>
                                    belum Diperiksa    
                                    <?php else: ?>
                                        <?php echo e($row->petugas->nama); ?>

                                    <?php endif; ?></td>
                                    <td><?php if($row->bakuda == null): ?>
                                        belum Diperiksa    
                                        <?php else: ?>
                                            <?php echo e($row->bakuda->nama); ?>

                                        <?php endif; ?></td>
                                    <td><?php echo e($row->report); ?></td>
                                    <td><?php echo e($row->created_at->format('Y-m-d H:i:s')); ?></td>
                                    <td><?php echo e($row->date_report); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('report.show',[$row->kd_berkas])); ?>" class="btn btn-info">Detail</a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($report->appends(Request::All())->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tafix\ta\resources\views/report/index.blade.php ENDPATH**/ ?>