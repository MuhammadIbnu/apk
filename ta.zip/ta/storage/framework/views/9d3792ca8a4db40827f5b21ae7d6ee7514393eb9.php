<?php $__env->startSection('title'); ?>
    Dashboard    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<link rel="stylesheet" href="<?php echo e(asset('chartjs/Chart.min.css')); ?>">
<script src="<?php echo e(asset('chartjs/Chart.min.js')); ?>"></script>
<div class="row">
    <div class="col-md-12">
        <div class="box">
            <div class="box-header with-border">
            </div>
            <div class="box-body">
                <div class="row">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                      <div class="info-box">
                        <span class="info-box-icon bg-aqua"><i class="ion ion-ios-people-outline"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">Aktivasi User</span>
                        <span class="info-box-number"><?php echo e($waris); ?></span>
                        </div>
                        <!-- /.info-box-content -->
                      </div>
                      <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                      <div class="info-box">
                        <span class="info-box-icon bg-red"><i class="ion ion-ios-list-outline"></i></span>
                  
                        <div class="info-box-content">
                          <span class="info-box-text">Jumlah Pengajuan</span>
                        <span class="info-box-number"><?php echo e($data); ?></span>
                        </div>
                        <!-- /.info-box-content -->
                      </div>
                      <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <!-- fix for small devices only -->
                    <div class="clearfix visible-sm-block"></div>
                  
                    <div class="col-md-3 col-sm-6 col-xs-12">
                      <div class="info-box">
                        <span class="info-box-icon bg-green"><i class="ion ion-ios-person-outline"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">Petugas Disdukcapil</span>
                        <span class="info-box-number"></span>
                        </div>
                        <!-- /.info-box-content -->
                      </div>
                      <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                    <div class="col-md-3 col-sm-6 col-xs-12">
                      <div class="info-box">
                        <span class="info-box-icon bg-green"><i class="ion ion-ios-person-outline"></i></span>
                        <div class="info-box-content">
                          <span class="info-box-text">Pegawai bakuda</span>
                        <span class="info-box-number"><?php echo e($bakuda); ?></span>
                        </div>
                        <!-- /.info-box-content -->
                      </div>
                      <!-- /.info-box -->
                    </div>
                    <!-- /.col -->
                  </div>
            </div>
        </div>
    </div>
</div>

<div class="row">
  <div class="col-md-12">
    <div class="box">
      <div class="box-header with-border">
             <h3>Grafik Kecamatan</h3>         
      </div>
      <div class="box-body">
        <canvas id="myChart"></canvas>
      </div>
    </div>
  </div>
</div>
<div class="row">
  <div class="col-md-6">
    <div class="box">
      <div class="box-header with-border">
             <h3>Data baru</h3>         
      </div>
      <div class="box-body">
        <table class="table table-bordered">
          <thead>
              <tr>
                  <th width="5%">No</th>
                  <th>Nama pengaju</th>
                  <th>Tanggal pengajuan</th>
              </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $data_masuk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($loop->iteration + ($data_masuk->perPage() *($data_masuk->currentPage()-1))); ?> </td>
                      <td><?php echo e($row->waris->nama); ?></td>
                      <td><?php echo e($row->created_at->format('d/m/Y')); ?></td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      <?php echo e($data_masuk->appends(Request::All())->links()); ?>

      </div>
    </div>
  </div>

  <div class="col-md-6">
    <div class="box">
      <div class="box-header with-border">
             <h3>Aktivasi Ahli Waris</h3>         
      </div>
      <div class="box-body">
        <table class="table table-bordered">
          <thead>
              <tr>
                  <th width="5%">No</th>
                  <th>Nama </th>
                  <th>Tanggal Aktivasi</th>
              </tr>
          </thead>
          <tbody>
              <?php $__currentLoopData = $aktivasi_baru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo e($loop->iteration + ($aktivasi_baru->perPage() *($aktivasi_baru->currentPage()-1))); ?> </td>
                      <td><?php echo e($row->nama); ?></td>
                      <td><?php echo e($row->created_at->format('d/m/Y H:i:s')); ?></td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
      <?php echo e($aktivasi_baru->appends(Request::All())->links()); ?>

      </div>
    </div>
  </div>
</div>
    

<script>
  var ctx = document.getElementById("myChart").getContext('2d');
  var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
      labels: <?php echo json_encode($kecamatan); ?>,
      datasets: [{
        label: 'Grafik pengajuan',
        data: <?php echo json_encode($jumlah_pengajuan); ?>,
        backgroundColor: 'rgba(255, 99, 132, 0.2)',
        borderColor: 'rgba(255,99,132,1)',
        borderWidth: 1
      }]
    },
    options: {
      scales: {
        yAxes: [{
          ticks: {
            beginAtZero:true
          }
        }]
      }
    }
  });
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tafix\ta\resources\views/home.blade.php ENDPATH**/ ?>