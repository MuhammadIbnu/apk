package mibnu.team.mobiledinkes.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import kotlinx.android.synthetic.main.activity_detail_data_report.*
import mibnu.team.mobiledinkes.R
import mibnu.team.mobiledinkes.models.Data
import mibnu.team.mobiledinkes.utils.Utilities
import mibnu.team.mobiledinkes.viewmodels.DataReportState
import mibnu.team.mobiledinkes.viewmodels.DataReportViewModel

class DetailDataReportActivity : AppCompatActivity() {
    private lateinit var dataReportViewModel: DataReportViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail_data_report)
        dataReportViewModel = ViewModelProvider(this).get(DataReportViewModel::class.java)
        dataReportViewModel.listenToUIState().observer(this, Observer { handleUi(it) })
        kirim()
        fill()
    }
    private fun kirim() {
        btn_answer.setOnClickListener {
            var token = "Bearer ${Utilities.getToken(this@DetailDataReportActivity)!!}"
            var id = getPassedData()?.kodeBerkas!!
            var answer = isitext.text.toString().trim()
            if (validate(answer)){
                dataReportViewModel.answerReport("Bearer ${Utilities.getToken(this@DetailDataReportActivity)!!}",id,answer)
            }


        }
    }
    fun validate(answer_report: String):Boolean{
        if (answer_report.isEmpty()){
            isitext.error="jangan kosong"
            return false
        }
        return true
    }
    private fun setErrorAnswer(err:String?){isitext.error=err}

    private fun handleUi(it: DataReportState) {
        when(it){
            is DataReportState.ShowToast -> Toast.makeText(this, it.message, Toast.LENGTH_SHORT).show()
            is DataReportState.Success -> finish()
//            is DataReportState.validate->{
//                it.answer_report?.let { e -> setErrorAnswer(e) }
//            }
        }


    }
    private fun getPassedData() = intent.getParcelableExtra<Data>("DATA")
    private fun fill(){
        getPassedData()?.let {
            nama.text = it.waris!!.nama
            kk.text = it.waris!!.kk
            nik.text = it.waris!!.nik
            if (it.confirmedI==true){
                status.text = "Sudah DiPeriksa"
            }else if (it.confirmedI==null){
                status.text = "Belum Diperiksa"
            }else{
                status.text = "Sudah diperiksa"
            }
            laporan.text=it.report
            dateLaporan.text=it.dateReport

            Glide.with(this)
                .load( it.ktpMeninggalUrl)
                .apply(RequestOptions())
                .into(img_Ktp_Meninggal)
            Glide.with(this)
                .load( it.kkMeninggalUrl)
                .apply(RequestOptions())
                .into(img_kk_meninggal)
            Glide.with(this)
                .load( it.jamkesmasMeninggalUrl)
                .apply(RequestOptions())
                .into(img_jamkesmas)
            Glide.with(this)
                .load( it.ktpWarisUrl)
                .apply(RequestOptions())
                .into(img_ktp_waris)
            Glide.with(this)
                .load(it.kkWarisUrl)
                .apply(RequestOptions())
                .into(img_kk_waris)
            Glide.with(this)
                .load( it.aktaKematianUrl)
                .apply(RequestOptions())
                .into(img_Akta_kematian)
            Glide.with(this)
                .load( it.paktaWarisUrl)
                .apply(RequestOptions())
                .into(img_integritas_waris)
            Glide.with(this)
                .load( it.pernyataanWarisUrl)
                .apply(RequestOptions())
                .into(img_pernyataan_waris)
            Glide.with(this)
                .load(it.bukuTabunganUrl)
                .apply(RequestOptions())
                .into(img_buku_tabungan)
            Glide.with(this)
                .load(it.imageReport)
                .apply(RequestOptions())
                .into(imgReport)

        }
    }
}