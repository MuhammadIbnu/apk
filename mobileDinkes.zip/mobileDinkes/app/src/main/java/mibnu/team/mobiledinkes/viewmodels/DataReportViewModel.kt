package mibnu.team.mobiledinkes.viewmodels

import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import mibnu.team.mobiledinkes.models.Data
import mibnu.team.mobiledinkes.utils.SingleLiveEvent
import mibnu.team.mobiledinkes.utils.Utilities
import mibnu.team.mobiledinkes.webservice.ApiClient
import mibnu.team.mobiledinkes.webservice.WrappedListResponse
import mibnu.team.mobiledinkes.webservice.WrappedResponse
import okhttp3.internal.Util
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DataReportViewModel : ViewModel(){
    private val api = ApiClient.instance()
    private var state : SingleLiveEvent<DataReportState> = SingleLiveEvent()
    private var reports= MutableLiveData<List<Data>>()

    private fun setLoading(){state.value = DataReportState.IsLoading(true)}
    private fun hideLoading(){state.value = DataReportState.IsLoading(false)}
    private fun showToast(message: String){state.value = DataReportState.ShowToast(message)}

    fun fetchDataReport(token:String){
        setLoading()
        api.dataReport(token).enqueue(object : Callback<WrappedListResponse<Data>> {
            override fun onResponse(
                call: Call<WrappedListResponse<Data>>,
                response: Response<WrappedListResponse<Data>>
            ) {
                if (response.isSuccessful){
                    val body = response.body()
                    println(body.toString())
                    reports.postValue(body?.data)
                }else{
                    showToast("kesalahan mengambil data")
                }
                hideLoading()
            }

            override fun onFailure(call: Call<WrappedListResponse<Data>>, t: Throwable) {
                println(t.message)
                println(t.printStackTrace())
                hideLoading()
                showToast(t.message.toString())
            }

        })
    }

    fun answerReport(token:String,id:Int,answer_report:String){
        state.value=DataReportState.IsLoading(true)
        api.answerReport(token,id.toString(),answer_report).enqueue(object : Callback<WrappedResponse<Data>>{
            override fun onResponse(
                call: Call<WrappedResponse<Data>>,
                response: Response<WrappedResponse<Data>>
            ) {
                if (response.isSuccessful){
                    val body = response.body()
                    if (body?.status!!){
                        state.value = DataReportState.ShowToast("Data Berhasil dikonfrimasi")
                        state.value = DataReportState.Success

                    }else{
                        state.value = DataReportState.ShowToast("gagal")
                    }
                }else{
                    state.value = DataReportState.ShowToast("gagal")
                    println("gagal")
                }
                state.value = DataReportState.IsLoading(false)
            }

            override fun onFailure(call: Call<WrappedResponse<Data>>, t: Throwable) {
                println("onFailure :"+t.message)
                println(t.printStackTrace())
                state.value = DataReportState.ShowToast("onFailure : "+t.message)
            }

        })
    }

    fun listenToUIState() = state
    fun listenToDataReport()= reports

}

sealed class DataReportState{
    data class IsLoading(var state : Boolean) : DataReportState()
    data class ShowToast(var message : String) : DataReportState()
    data class validate(var answer_report: String? = null):DataReportState()
    object Reset : DataReportState()
    object Success: DataReportState()
}