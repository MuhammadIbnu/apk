package mibnu.team.mobiledinkes.view

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import kotlinx.android.synthetic.main.activity_data_report.*
import kotlinx.android.synthetic.main.activity_data_valid.*
import kotlinx.android.synthetic.main.activity_data_report.loading
import kotlinx.android.synthetic.main.activity_data_report.rv_data
import kotlinx.android.synthetic.main.item_data_report.*
import mibnu.team.mobiledinkes.R
import mibnu.team.mobiledinkes.adapter.DataReportAdapter
import mibnu.team.mobiledinkes.models.Data
import mibnu.team.mobiledinkes.utils.Utilities
import mibnu.team.mobiledinkes.viewmodels.DataReportState
import mibnu.team.mobiledinkes.viewmodels.DataReportViewModel

class DataReportActivity : AppCompatActivity() {
   private lateinit var dataReportViewModel: DataReportViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_data_report)
        dataReportViewModel = ViewModelProvider(this).get(DataReportViewModel::class.java)
        dataReportViewModel.listenToUIState().observer(this, Observer { handleUIState(it) })
        dataReportViewModel.listenToDataReport().observe(this, Observer { handleData(it)  })
        setupUi()
    }

    private fun setupUi() {
        rv_data.apply {
            layoutManager = LinearLayoutManager(this@DataReportActivity)
            adapter = DataReportAdapter(mutableListOf(),this@DataReportActivity)
        }
    }

    private fun handleData(it : List<Data>){
        rv_data.adapter?.let { adapter ->
            adapter as DataReportAdapter
            adapter.updateList(it)
        }
    }

    private fun handleUIState(it: DataReportState){
        when(it){
            is DataReportState.ShowToast -> toast(it.message)
            is DataReportState.IsLoading ->{
                if (it.state){
                    loading.visibility = View.VISIBLE
                }else{
                    loading.visibility = View.GONE
                }
            }
        }
    }
    private fun toast(m : String) = Toast.makeText(this, m, Toast.LENGTH_LONG).show()

    override fun onResume() {
        super.onResume()
        Utilities.getToken(this)?.let { t -> dataReportViewModel.fetchDataReport("Bearer $t") }
    }
}